# GPSBridge
Android application for streaming GPS, compass and orientation data to a computer over Bluetooth RFCOMM in JSON format.
# GPS Bridge

A **GPS Bridge** egy Android alkalmazás, amely a telefon helymeghatározási és tájolási adatait Bluetooth RFCOMM kapcsolaton keresztül továbbítja egy számítógépnek.

A telefon külső Bluetooth GPS-, iránytű- és helyzetérzékelőként használható. Az alkalmazás a mért adatokat UTF-8 kódolású, soronként egy JSON objektumot tartalmazó adatfolyamban küldi.

## Főbb funkciók

- GPS-koordináták továbbítása
- magasság és helymeghatározási pontosság továbbítása
- sebesség és GPS szerinti haladási irány továbbítása
- mágneses északi irány meghatározása
- valódi északi irány számítása a helyi mágneses deklináció alapján
- pitch és roll érték továbbítása
- Bluetooth RFCOMM / Serial Port Profile kapcsolat
- folyamatos, közel 5 Hz-es JSON adatfolyam
- egyszerű magyar nyelvű Android kezelőfelület

## Követelmények

- Android 8.1 vagy újabb rendszer
- GPS-vevő
- Bluetooth adapter
- `TYPE_ROTATION_VECTOR` szenzor
- iránytűszenzor

A projekt fontosabb Android-beállításai:

| Beállítás | Érték |
|---|---:|
| Minimum Android API | 27 |
| Target Android API | 33 |
| Compile SDK | 33 |
| Programnyelv | Kotlin |
| JVM target | Java 8 |
| Application ID | `hu.digitalsinus.gpsbridge` |

## Bluetooth kapcsolat

Az alkalmazás Bluetooth RFCOMM szerverként működik.

| Paraméter | Érték |
|---|---|
| Szolgáltatás neve | `GPS Bridge` |
| RFCOMM UUID | `00001101-0000-1000-8000-00805F9B34FB` |
| Profil | Serial Port Profile kompatibilis RFCOMM kapcsolat |
| Karakterkódolás | UTF-8 |
| Üzenethatárolás | LF, azaz `\n` |
| Küldési periódus | 200 ms |
| Névleges küldési gyakoriság | körülbelül 5 Hz |

Az alkalmazás egyszerre egy RFCOMM klienskapcsolatot kezel. A kapcsolat megszakadása után új kliens csatlakozására vár.

## Használat

1. Párosítsd a telefont a fogadó számítógéppel.
2. Indítsd el a GPS Bridge alkalmazást.
3. Engedélyezd a kért helymeghatározási és Bluetooth-jogosultságokat.
4. Kapcsold be a telefon helymeghatározását és Bluetooth adapterét.
5. Nyomd meg az **Indítás** gombot.
6. A számítógépen csatlakozz a `GPS Bridge` nevű RFCOMM szolgáltatáshoz.
7. A kapcsolat létrejötte után az alkalmazás folyamatosan küldi a JSON sorokat.
8. A leállításhoz nyomd meg a **Leállítás** gombot.

A kezelőfelület megjeleníti:

- a Bluetooth-szerver állapotát;
- a klienskapcsolat állapotát;
- az aktuális helymeghatározási adatokat;
- a mágneses és valódi irányt;
- a pitch és roll értékeket;
- az utoljára elküldött JSON sort.

# JSON adatprotokoll

## Általános formátum

Minden elküldött rekord egyetlen JSON objektum. Az objektumot egy LF sortörés zárja le:

```text
{JSON objektum}\n
```

Ez tehát **newline-delimited JSON**, röviden NDJSON jellegű adatfolyam. Egy teljes sor egy önállóan feldolgozható rekord.

Az alkalmazás a mezőket mindig ugyanabban a logikai sorrendben teszi a JSON objektumba:

```json
{
  "time": "2026-07-12T09:30:15.123Z",
  "lat": 47.4979,
  "lon": 19.0402,
  "alt": 118.4,
  "gps_accuracy": 4.2,
  "speed": 0.3,
  "course": 125.0,
  "location_time_ms": 1783848615123,
  "provider": "gps",
  "heading_mag": 182.4,
  "heading_true": 187.1,
  "pitch": -3.2,
  "roll": 1.5,
  "heading_accuracy": 3
}
```

A tényleges Bluetooth adatfolyamban ugyanez egyetlen sorban jelenik meg, majd `\n` karakter követi:

```json
{"time":"2026-07-12T09:30:15.123Z","lat":47.4979,"lon":19.0402,"alt":118.4,"gps_accuracy":4.2,"speed":0.3,"course":125.0,"location_time_ms":1783848615123,"provider":"gps","heading_mag":182.4,"heading_true":187.1,"pitch":-3.2,"roll":1.5,"heading_accuracy":3}
```

## A mezők pontos jelentése

| Mező | JSON-típus | Mértékegység | Leírás |
|---|---|---|---|
| `time` | string | UTC idő | A JSON rekord létrehozásának időpontja `yyyy-MM-dd'T'HH:mm:ss.SSS'Z'` formátumban. |
| `lat` | number vagy `null` | fok | Földrajzi szélesség WGS84 koordinátában. |
| `lon` | number vagy `null` | fok | Földrajzi hosszúság WGS84 koordinátában. |
| `alt` | number vagy `null` | méter | A `Location` objektum által szolgáltatott magasság. |
| `gps_accuracy` | number vagy `null` | méter | A helymeghatározás becsült vízszintes pontossága. |
| `speed` | number vagy `null` | m/s | A `Location` objektum által szolgáltatott sebesség. |
| `course` | number vagy `null` | fok | A GPS/helymeghatározás szerinti haladási irány. Ez nem azonos a telefon iránytű szerinti tájolásával. |
| `location_time_ms` | integer vagy `null` | ms Unix epoch óta | A felhasznált Android `Location` mérés időbélyege. |
| `provider` | string vagy `null` | — | A helyadat szolgáltatója, például `gps` vagy `network`. |
| `heading_mag` | number vagy `null` | fok | A telefon mágneses északi irányhoz viszonyított tájolása, 0 és 360 fok között normalizálva. |
| `heading_true` | number vagy `null` | fok | Valódi északi irányhoz viszonyított tájolás, a helyi mágneses deklinációval korrigálva. |
| `pitch` | number vagy `null` | fok | A telefon pitch szöge az Android rotation vector orientációjából. |
| `roll` | number vagy `null` | fok | A telefon roll szöge az Android rotation vector orientációjából. |
| `heading_accuracy` | integer vagy `null` | Android szenzorpontossági kód | A rotation vector szenzor által jelentett pontossági állapot. |

## `null` értékek

A mezők nem maradnak ki. Ha egy adat még nem érhető el, a program az adott mező értékeként JSON `null` értéket küld.

Példa közvetlenül az indulás után, amikor még nincs helyadat és szenzoradat:

```json
{"time":"2026-07-12T09:30:15.123Z","lat":null,"lon":null,"alt":null,"gps_accuracy":null,"speed":null,"course":null,"location_time_ms":null,"provider":null,"heading_mag":null,"heading_true":null,"pitch":null,"roll":null,"heading_accuracy":null}
```

Részleges adat esetén csak a nem elérhető mezők lesznek `null` értékűek. Például a helyadat már rendelkezésre állhat úgy is, hogy a sebesség vagy a GPS szerinti haladási irány még nem ismert.

## Időbélyegek

A protokoll két külön időadatot tartalmaz:

### `time`

A JSON sor létrehozásának aktuális rendszerideje UTC-ben:

```text
2026-07-12T09:30:15.123Z
```

### `location_time_ms`

Az Android helymeghatározási mérés időpontja ezredmásodpercben, Unix epoch óta. Ez nem feltétlenül egyezik meg pontosan a JSON rekord létrehozási idejével, mert ugyanaz a legutóbbi helymérés több egymást követő JSON rekordban is szerepelhet.

## Irányadatok

### `course`

A `course` a helymeghatározó rendszer által megadott haladási irány. Álló vagy nagyon lassan mozgó készüléknél nem feltétlenül áll rendelkezésre, ezért `null` lehet.

### `heading_mag`

A `heading_mag` a telefon rotation vector szenzorából számított, mágneses északi irányhoz viszonyított tájolás.

### `heading_true`

A program a valódi északi irányt az Android `GeomagneticField` osztályával számítja:

```text
heading_true = heading_mag + helyi mágneses deklináció
```

Az eredmény 0 és 360 fok közé van normalizálva. A számításhoz az aktuális szélességet, hosszúságot, magasságot és rendszeridőt használja. Helyadat hiányában a `heading_true` értéke `null`.

## `heading_accuracy` értékek

A mező az Android `SensorManager` pontossági kódját tartalmazza:

| Érték | Android jelentés |
|---:|---|
| `0` | `SENSOR_STATUS_UNRELIABLE` |
| `1` | `SENSOR_STATUS_ACCURACY_LOW` |
| `2` | `SENSOR_STATUS_ACCURACY_MEDIUM` |
| `3` | `SENSOR_STATUS_ACCURACY_HIGH` |
| `null` | A szenzor még nem jelentett pontossági állapotot. |

## Egyszerű Linux klienspélda

Miután a Bluetooth RFCOMM kapcsolat létrejött és a rendszerben például `/dev/rfcomm0` eszközként elérhető, az adatfolyam egyszerűen olvasható:

```bash
cat /dev/rfcomm0
```

A sorok feldolgozhatók például `jq` segítségével:

```bash
cat /dev/rfcomm0 | jq -c .
```

Csak a pozíció kiírása:

```bash
cat /dev/rfcomm0 |
while IFS= read -r line
do
	printf '%s\n' "$line" |
	jq -r '[.time, .lat, .lon, .alt] | @tsv'
done
```

A kliensprogramnak soronként kell olvasnia az adatfolyamot, majd minden teljes sort külön JSON objektumként feldolgoznia.

## Fordítás

A projekt Android Studio használatával nyitható meg, vagy a mellékelt Gradle Wrapperrel parancssorból is fordítható.

Debug APK készítése:

```bash
./gradlew assembleDebug
```

A létrejövő APK alapértelmezett helye:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Release build készítése:

```bash
./gradlew assembleRelease
```

A release APK publikálásához külön aláírási konfiguráció szükséges.

## Szükséges Android-jogosultságok

Az alkalmazás a következő jogosultságokat használja:

- `ACCESS_FINE_LOCATION`
- `ACCESS_COARSE_LOCATION`
- `BLUETOOTH` Android 11-ig
- `BLUETOOTH_ADMIN` Android 11-ig
- `BLUETOOTH_CONNECT` Android 12-től
- `BLUETOOTH_SCAN` Android 12-től

## Projektfelépítés

```text
GPSBridge/
├── app/
│   ├── src/main/
│   │   ├── java/hu/digitalsinus/gpsbridge/MainActivity.kt
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── gradle/wrapper/
├── build.gradle
├── settings.gradle
├── gradlew
└── gradlew.bat
```

A teljes alkalmazás fő működése jelenleg a `MainActivity.kt` fájlban található:

- jogosultságkezelés;
- GPS- és hálózati helyfrissítések kezelése;
- rotation vector szenzor olvasása;
- mágneses és valódi irány számítása;
- RFCOMM szerver létrehozása;
- klienskapcsolat kezelése;
- JSON rekordok előállítása és küldése.

## Korlátozások

- Az alkalmazásnak az előtérben kell futnia; külön Android foreground service nincs megvalósítva.
- Egyszerre egy Bluetooth klienskapcsolatot kezel.
- A küldési periódus 200 ms, de az új GPS-mérések tényleges gyakoriságát a telefon hardvere és az Android helymeghatározó rendszere határozza meg.
- Két GPS-frissítés között több JSON rekord is tartalmazhatja ugyanazt a helyadatot.
- A mágneses irányt a környező fémek, mágnesek, hangszórók és elektromos berendezések jelentősen befolyásolhatják.
- A pontos irányméréshez szükség lehet a telefon iránytűjének kalibrálására.

## Licenc

A projekt licencét a repository `LICENSE` fájlja határozza meg.
