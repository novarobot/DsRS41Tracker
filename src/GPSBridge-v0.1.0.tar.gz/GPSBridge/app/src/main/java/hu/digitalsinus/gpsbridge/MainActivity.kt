package hu.digitalsinus.gpsbridge

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI

class MainActivity : AppCompatActivity(), SensorEventListener, LocationListener
{
    companion object
    {
        private const val REQUEST_PERMISSIONS = 1001
        private const val SERVICE_NAME = "GPS Bridge"
        private const val SEND_INTERVAL_MS = 200L

        private val SERVICE_UUID: UUID =
            UUID.fromString(
                "00001101-0000-1000-8000-00805F9B34FB"
            )
    }

    private lateinit var textBluetoothStatus: TextView
    private lateinit var textGpsStatus: TextView
    private lateinit var textHeadingStatus: TextView
    private lateinit var textClientStatus: TextView
    private lateinit var textLastJson: TextView

    private lateinit var buttonStart: Button
    private lateinit var buttonStop: Button

    private lateinit var locationManager: LocationManager
    private lateinit var sensorManager: SensorManager

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var rotationVectorSensor: Sensor? = null

    @Volatile
    private var latestLocation: Location? = null

    @Volatile
    private var magneticHeading: Double? = null

    @Volatile
    private var trueHeading: Double? = null

    @Volatile
    private var pitchDegrees: Double? = null

    @Volatile
    private var rollDegrees: Double? = null

    @Volatile
    private var sensorAccuracy: Int? = null

    @Volatile
    private var serverSocket: BluetoothServerSocket? = null

    @Volatile
    private var clientSocket: BluetoothSocket? = null

    private var bluetoothThread: Thread? = null

    private val running = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textBluetoothStatus =
            findViewById(R.id.textBluetoothStatus)

        textGpsStatus =
            findViewById(R.id.textGpsStatus)

        textHeadingStatus =
            findViewById(R.id.textHeadingStatus)

        textClientStatus =
            findViewById(R.id.textClientStatus)

        textLastJson =
            findViewById(R.id.textLastJson)

        buttonStart =
            findViewById(R.id.buttonStart)

        buttonStop =
            findViewById(R.id.buttonStop)

        locationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        rotationVectorSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ROTATION_VECTOR
            )

        val bluetoothManager =
            getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager

        bluetoothAdapter = bluetoothManager.adapter

        buttonStart.setOnClickListener {
            requestPermissionsAndStart()
        }

        buttonStop.setOnClickListener {
            stopBridge()
        }

        if (rotationVectorSensor == null)
        {
            textHeadingStatus.text =
                "Iránytű: rotation vector szenzor nem található"
        }

        if (bluetoothAdapter == null)
        {
            textBluetoothStatus.text =
                "Bluetooth: adapter nem található"

            buttonStart.isEnabled = false
        }
    }

    private fun requestPermissionsAndStart()
    {
        val permissions = mutableListOf<String>()

        if (
            checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        )
        {
            permissions.add(
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        {
            if (
                checkSelfPermission(
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            )
            {
                permissions.add(
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            }

            if (
                checkSelfPermission(
                    Manifest.permission.BLUETOOTH_SCAN
                ) != PackageManager.PERMISSION_GRANTED
            )
            {
                permissions.add(
                    Manifest.permission.BLUETOOTH_SCAN
                )
            }
        }

        if (permissions.isNotEmpty())
        {
            requestPermissions(
                permissions.toTypedArray(),
                REQUEST_PERMISSIONS
            )

            return
        }

        startBridge()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    )
    {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode != REQUEST_PERMISSIONS)
        {
            return
        }

        val allGranted =
            grantResults.isNotEmpty() &&
                    grantResults.all {
                        it == PackageManager.PERMISSION_GRANTED
                    }

        if (allGranted)
        {
            startBridge()
        }
        else
        {
            showToast(
                "A szükséges jogosultságok nincsenek engedélyezve."
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBridge()
    {
        if (running.get())
        {
            return
        }

        val adapter = bluetoothAdapter

        if (adapter == null)
        {
            showToast("Bluetooth adapter nem található.")
            return
        }

        if (!adapter.isEnabled)
        {
            showToast("Kapcsold be a Bluetooth-t.")
            return
        }

        if (
            checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        )
        {
            requestPermissionsAndStart()
            return
        }

        running.set(true)

        buttonStart.isEnabled = false
        buttonStop.isEnabled = true

        startSensors()
        startLocationUpdates()
        startBluetoothServer()
    }

    private fun startSensors()
    {
        val sensor = rotationVectorSensor

        if (sensor == null)
        {
            return
        }

        sensorManager.registerListener(
            this,
            sensor,
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates()
    {
        try
        {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                200L,
                0.0f,
                this,
                Looper.getMainLooper()
            )

            if (
                locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER
                )
            )
            {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    1000L,
                    0.0f,
                    this,
                    Looper.getMainLooper()
                )
            }

            textGpsStatus.text =
                "GPS: pozícióra vár"
        }
        catch (exception: Exception)
        {
            textGpsStatus.text =
                "GPS hiba: ${exception.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBluetoothServer()
    {
        bluetoothThread = Thread {
            try
            {
                runOnUiThread {
                    textBluetoothStatus.text =
                        "Bluetooth: RFCOMM szerver indul"

                    textClientStatus.text =
                        "PC kapcsolat: csatlakozásra vár"
                }

                val adapter = bluetoothAdapter
                    ?: throw IOException(
                        "Bluetooth adapter nem található"
                    )

                serverSocket =
                    adapter.listenUsingRfcommWithServiceRecord(
                        SERVICE_NAME,
                        SERVICE_UUID
                    )

                runOnUiThread {
                    textBluetoothStatus.text =
                        "Bluetooth: RFCOMM szerver aktív"
                }

                while (running.get())
                {
                    val socket =
                        serverSocket?.accept()
                            ?: break

                    clientSocket = socket

                    runOnUiThread {
                        textClientStatus.text =
                            "PC kapcsolat: csatlakoztatva"
                    }

                    try
                    {
                        sendLoop(socket.outputStream)
                    }
                    catch (exception: Exception)
                    {
                        if (running.get())
                        {
                            runOnUiThread {
                                textClientStatus.text =
                                    "PC kapcsolat megszakadt: " +
                                            "${exception.message}"
                            }
                        }
                    }
                    finally
                    {
                        closeClientSocket()
                    }

                    if (running.get())
                    {
                        runOnUiThread {
                            textClientStatus.text =
                                "PC kapcsolat: csatlakozásra vár"
                        }
                    }
                }
            }
            catch (exception: Exception)
            {
                if (running.get())
                {
                    runOnUiThread {
                        textBluetoothStatus.text =
                            "Bluetooth hiba: ${exception.message}"
                    }
                }
            }
            finally
            {
                closeClientSocket()
                closeServerSocket()
            }
        }

        bluetoothThread?.name =
            "GpsBridgeBluetoothServer"

        bluetoothThread?.start()
    }

    private fun sendLoop(outputStream: OutputStream)
    {
        while (
            running.get() &&
            clientSocket?.isConnected == true
        )
        {
            val jsonLine = createJsonLine()

            outputStream.write(
                jsonLine.toByteArray(Charsets.UTF_8)
            )

            outputStream.flush()

            runOnUiThread {
                textLastJson.text =
                    "Utolsó elküldött JSON:\n" +
                            jsonLine.trim()
            }

            Thread.sleep(SEND_INTERVAL_MS)
        }
    }

    private fun createJsonLine(): String
    {
        val location = latestLocation
        val json = JSONObject()

        json.put(
            "time",
            createUtcTimestamp()
        )

        if (location != null)
        {
            json.put(
                "lat",
                location.latitude
            )

            json.put(
                "lon",
                location.longitude
            )

            putLocationValue(
                json,
                "alt",
                location.hasAltitude(),
                location.altitude
            )

            putLocationValue(
                json,
                "gps_accuracy",
                location.hasAccuracy(),
                location.accuracy.toDouble()
            )

            putLocationValue(
                json,
                "speed",
                location.hasSpeed(),
                location.speed.toDouble()
            )

            putLocationValue(
                json,
                "course",
                location.hasBearing(),
                location.bearing.toDouble()
            )

            json.put(
                "location_time_ms",
                location.time
            )

            json.put(
                "provider",
                location.provider ?: JSONObject.NULL
            )
        }
        else
        {
            json.put("lat", JSONObject.NULL)
            json.put("lon", JSONObject.NULL)
            json.put("alt", JSONObject.NULL)
            json.put("gps_accuracy", JSONObject.NULL)
            json.put("speed", JSONObject.NULL)
            json.put("course", JSONObject.NULL)
            json.put("location_time_ms", JSONObject.NULL)
            json.put("provider", JSONObject.NULL)
        }

        putNullableDouble(
            json,
            "heading_mag",
            magneticHeading
        )

        putNullableDouble(
            json,
            "heading_true",
            trueHeading
        )

        putNullableDouble(
            json,
            "pitch",
            pitchDegrees
        )

        putNullableDouble(
            json,
            "roll",
            rollDegrees
        )

        if (sensorAccuracy == null)
        {
            json.put(
                "heading_accuracy",
                JSONObject.NULL
            )
        }
        else
        {
            json.put(
                "heading_accuracy",
                sensorAccuracy
            )
        }

        return json.toString() + "\n"
    }

    private fun putLocationValue(
        json: JSONObject,
        name: String,
        hasValue: Boolean,
        value: Double
    )
    {
        if (hasValue)
        {
            json.put(
                name,
                value
            )
        }
        else
        {
            json.put(
                name,
                JSONObject.NULL
            )
        }
    }

    private fun putNullableDouble(
        json: JSONObject,
        name: String,
        value: Double?
    )
    {
        if (value == null)
        {
            json.put(
                name,
                JSONObject.NULL
            )
        }
        else
        {
            json.put(
                name,
                value
            )
        }
    }

    private fun createUtcTimestamp(): String
    {
        val format =
            SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                Locale.US
            )

        format.timeZone =
            TimeZone.getTimeZone("UTC")

        return format.format(Date())
    }

    override fun onSensorChanged(event: SensorEvent?)
    {
        if (
            event == null ||
            event.sensor.type != Sensor.TYPE_ROTATION_VECTOR
        )
        {
            return
        }

        val rotationMatrix = FloatArray(9)
        val orientation = FloatArray(3)

        SensorManager.getRotationMatrixFromVector(
            rotationMatrix,
            event.values
        )

        SensorManager.getOrientation(
            rotationMatrix,
            orientation
        )

        val heading =
            normalizeDegrees(
                radiansToDegrees(
                    orientation[0].toDouble()
                )
            )

        val pitch =
            radiansToDegrees(
                orientation[1].toDouble()
            )

        val roll =
            radiansToDegrees(
                orientation[2].toDouble()
            )

        magneticHeading = heading
        pitchDegrees = pitch
        rollDegrees = roll

        trueHeading =
            calculateTrueHeading(
                heading,
                latestLocation
            )

        val trueText =
            trueHeading?.let {
                String.format(
                    Locale.US,
                    "%.1f",
                    it
                )
            } ?: "?"

        textHeadingStatus.text =
            String.format(
                Locale.US,
                "Iránytű: mágneses %.1f°\n" +
                        "Valódi: %s°\n" +
                        "Pitch: %.1f°  Roll: %.1f°",
                heading,
                trueText,
                pitch,
                roll
            )
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    )
    {
        if (
            sensor?.type ==
            Sensor.TYPE_ROTATION_VECTOR
        )
        {
            sensorAccuracy = accuracy
        }
    }

    @Suppress("DEPRECATION")
    override fun onStatusChanged(
        provider: String?,
        status: Int,
        extras: Bundle?
    )
    {
        /*
         * Android 8.1 kompatibilitás miatt szükséges.
         */
    }

    override fun onProviderEnabled(provider: String)
    {
        if (!running.get())
        {
            return
        }

        textGpsStatus.text =
            "Helymeghatározás bekapcsolva: $provider\n" +
                    "Pozícióra vár..."
    }

    override fun onProviderDisabled(provider: String)
    {
        if (!running.get())
        {
            return
        }

        textGpsStatus.text =
            "Helymeghatározás kikapcsolva: $provider"
    }

    override fun onLocationChanged(location: Location)
    {
        val previous = latestLocation

        if (
            previous == null ||
            location.time >= previous.time ||
            location.provider == LocationManager.GPS_PROVIDER
        )
        {
            latestLocation = location
        }

        trueHeading =
            magneticHeading?.let {
                calculateTrueHeading(
                    it,
                    latestLocation
                )
            }

        val altitude =
            if (location.hasAltitude())
            {
                String.format(
                    Locale.US,
                    "%.1f",
                    location.altitude
                )
            }
            else
            {
                "?"
            }

        val accuracy =
            if (location.hasAccuracy())
            {
                String.format(
                    Locale.US,
                    "%.1f",
                    location.accuracy
                )
            }
            else
            {
                "?"
            }

        textGpsStatus.text =
            String.format(
                Locale.US,
                "GPS: %.6f, %.6f\n" +
                        "Magasság: %s m\n" +
                        "Pontosság: %s m\n" +
                        "Provider: %s",
                location.latitude,
                location.longitude,
                altitude,
                accuracy,
                location.provider ?: "?"
            )
    }

    private fun calculateTrueHeading(
        magnetic: Double,
        location: Location?
    ): Double?
    {
        if (location == null)
        {
            return null
        }

        val altitude =
            if (location.hasAltitude())
            {
                location.altitude.toFloat()
            }
            else
            {
                0.0f
            }

        val geomagneticField =
            GeomagneticField(
                location.latitude.toFloat(),
                location.longitude.toFloat(),
                altitude,
                System.currentTimeMillis()
            )

        return normalizeDegrees(
            magnetic +
                    geomagneticField.declination.toDouble()
        )
    }

    private fun radiansToDegrees(value: Double): Double
    {
        return value * 180.0 / PI
    }

    private fun normalizeDegrees(value: Double): Double
    {
        var result = value % 360.0

        if (result < 0.0)
        {
            result += 360.0
        }

        return result
    }

    private fun stopBridge()
    {
        if (!running.getAndSet(false))
        {
            return
        }

        try
        {
            locationManager.removeUpdates(this)
        }
        catch (_: SecurityException)
        {
        }

        sensorManager.unregisterListener(this)

        closeClientSocket()
        closeServerSocket()

        bluetoothThread?.interrupt()
        bluetoothThread = null

        buttonStart.isEnabled = true
        buttonStop.isEnabled = false

        textBluetoothStatus.text =
            "Bluetooth: leállítva"

        textGpsStatus.text =
            "GPS: leállítva"

        textHeadingStatus.text =
            "Iránytű: leállítva"

        textClientStatus.text =
            "PC kapcsolat: nincs"
    }

    private fun closeClientSocket()
    {
        try
        {
            clientSocket?.close()
        }
        catch (_: IOException)
        {
        }

        clientSocket = null
    }

    private fun closeServerSocket()
    {
        try
        {
            serverSocket?.close()
        }
        catch (_: IOException)
        {
        }

        serverSocket = null
    }

    private fun showToast(message: String)
    {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDestroy()
    {
        stopBridge()
        super.onDestroy()
    }
}